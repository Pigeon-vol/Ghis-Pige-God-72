========================
test-add_enumerable_node
========================

.. toctree::
   :numbered:


First section
=============

.. _first_figure:

.. figure:: rimg.png

   First figure

.. _first_my_figure:

.. my-figure:: rimg.png

   First my figure

.. _first_numbered_text:

.. numbered-text:: Hello world

.. _second_numbered_text:

.. numbered-text:: Hello Sphinx

Second section
==============

.. _second_my_figure:

.. my-figure:: rimg.png

   Second my figure

Reference section
=================

* first_figure is :numref:`first_figure`
* first_my_figure is :numref:`first_my_figure`
* second_my_figure is :numref:`second_my_figure`
* first numbered_text is :numref:`first_numbered_text`
* second numbered_text is :numref:`second_numbered_text`
