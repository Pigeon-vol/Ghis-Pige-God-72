:tocdepth: 1

.. default-role:: any

.. _changes:

=========
Changelog
=========

.. raw:: latex

   \addtocontents{toc}{\protect\setcounter{tocdepth}{1}}%

.. include:: ../CHANGES
