# Dinosaure
Python project to validate my ISN graduation
