#!/bin/bash

rm -rf corpus_to_align;
rm -rf input_documents;
rm -rf src/alignments;
rm -rf src/diagonals;
rm -rf src/lexical_distributions;
rm -rf src/numbering_maps;
rm -rf src/output_data_aligned;
rm -rf src/training_data;
