#!/bin/bash

mkdir corpus_to_align/source_language_corpus_prepared
mkdir corpus_to_align/target_language_corpus_prepared

perl lowercase-all.perl



